package ConferenceRegistration;

import java.util.List;
import java.util.regex.Pattern;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import PageBean.PageFactoryRegistration;
import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefRegistration {
	
	private WebDriver driver;
	private PageFactoryRegistration obj;
	private int i=0;
	
	
	public void alertMsg() throws InterruptedException {
		String alertMsg=driver.switchTo().alert().getText();
		System.out.println("***"+alertMsg);
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
	}
	
	@Given("^User is on the conference registration page$")
	public void user_is_on_the_conference_registration_page() throws Throwable {
		driver=new FirefoxDriver();
	    obj=new PageFactoryRegistration(driver);
	    Thread.sleep(1000);
	    driver.get("file:///D:/BDD%20MPT%20case%20study/ConferenceRegistartion.html/");
	}

	@Then("^The title is verified$")
	public void the_title_is_verified() throws Throwable {
		if(driver.getTitle().contentEquals("Conference Registration"))
			   System.out.println("***Title Matched***");
		   else
			   System.out.println("***Title mismatch***");
		   
		   driver.close();
	}

	@When("^User leaves first name blank and clicks on the link next$")
	public void user_leaves_first_name_blank_and_clicks_on_the_link_next() throws Throwable {
	   
	}

	@Then("^Display alert message$")
	public void Display_alert_message() throws Throwable {
		obj.setClick();
	    alertMsg();
	    driver.close();  
	}

	@When("^Use enters first name and leaves the last name and clicks on the link next$")
	public void use_enters_first_name_and_leaves_the_last_name_and_clicks_on_the_link_next() throws Throwable {
		obj.setFname("Supriya");
		obj.setLname("");
		Thread.sleep(1000);
	}

	@When("^Use enters incorrect email format$")
	public void use_enters_incorrect_email_format() throws Throwable {
		obj.setFname("Supriya");
		obj.setLname("Palaparthi");
		obj.setEmail("priya");
		Thread.sleep(1000);
	}

	@When("^User leaves mobile number blank and clicks on the link next$")
	public void user_leaves_mobile_number_blank_and_clicks_on_the_link_next() throws Throwable {
		obj.setFname("Supriya");
		obj.setLname("Palaparthi");
		obj.setEmail("supriya.palaparthi@capgemini.com");
		obj.setPhone("");
	}

	@When("^User enters incorrect mobilenumber format and clicks the button$")
	public void user_enters_incorrect_mobilenumber_format_and_clicks_the_button(DataTable arg1) throws Throwable {
		List<List<String>> data=arg1.raw();
		obj.setFname("Supriya");
		obj.setLname("Palaparthi");
		obj.setEmail("supriya.palaparthi@capgemini.com");Thread.sleep(1000);
		
		
		
		for (i=0;i<data.size();i++) {
			obj.getPhone().clear();
			obj.setPhone(data.get(i).get(0));
			obj.setClick();
			
			
			if(Pattern.matches("^[7-9]{1}[0-9]{9}$",data.get(i).get(0)))
				System.out.println(data.get(i).get(0)+" \tMatched");
				
			else {
				System.out.println(data.get(i).get(0)+"\tMismatched");
				alertMsg();
			}
		}   
	}

	@Then("^display alert message$")
	public void display_alert_message() throws Throwable {
		String alertMsg=driver.switchTo().alert().getText();
		System.out.println("***"+alertMsg);
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^User doesnot select the number of people and clicks on the link next$")
	public void user_doesnot_select_the_number_of_people_and_clicks_on_the_link_next() throws Throwable {
		obj.setFname("Supriya");
		obj.setLname("Palaparthi");
		obj.setEmail("supriya.palaparthi@capgemini.com");
		obj.setPhone("9966922993");
		obj.setPeople("");
		Thread.sleep(1000);
	}

	@When("^User leaves the address blank and clicks on the link next$")
	public void user_leaves_the_address_blank_and_clicks_on_the_link_next() throws Throwable {
		obj.setFname("Supriya");
		obj.setLname("Palaparthi");
		obj.setEmail("supriya.palaparthi@capgemini.com");
		obj.setPhone("9966922993");
		obj.setPeople("3");
		obj.setAddress("");
		Thread.sleep(1000);
	}

	@When("^User leaves the area name blank and clicks on the link next$")
	public void user_leaves_the_area_name_blank_and_clicks_on_the_link_next() throws Throwable {
		obj.setFname("Supriya");
		obj.setLname("Palaparthi");
		obj.setEmail("supriya.palaparthi@capgemini.com");
		obj.setPhone("9966922993");
		obj.setPeople("3");
		obj.setAddress("110");
		obj.setAddress2("");
		Thread.sleep(1000);
	}

	@When("^User doesnot select any city and clicks on the link next$")
	public void user_doesnot_select_any_city_and_clicks_on_the_link_next() throws Throwable {
		obj.setFname("Supriya");
		obj.setLname("Palaparthi");
		obj.setEmail("supriya.palaparthi@capgemini.com");
		obj.setPhone("9966922993");
		obj.setPeople("3");
		obj.setAddress("110");
		obj.setAddress2("Chintal");
		obj.setScity("");
		Thread.sleep(1000);
	}

	@When("^User doesnot select any state and clicks on the link next$")
	public void user_doesnot_select_any_state_and_clicks_on_the_link_next() throws Throwable {
		obj.setFname("Supriya");
		obj.setLname("Palaparthi");
		obj.setEmail("supriya.palaparthi@capgemini.com");
		obj.setPhone("9966922993");
		obj.setPeople("3");
		obj.setAddress("110");
		obj.setAddress2("Chintal");
		obj.setScity("Hyderabad");
		obj.setSstate("");
		Thread.sleep(1000);
	}

	@When("^Use doesnot select any of the button$")
	public void use_doesnot_select_any_of_the_button() throws Throwable {
		obj.setFname("Supriya");
		obj.setLname("Palaparthi");
		obj.setEmail("supriya.palaparthi@capgemini.com");
		obj.setPhone("9966922993");
		obj.setPeople("3");
		obj.setAddress("110");
		obj.setAddress2("Chintal");
		obj.setScity("Hyderabad");
		obj.setSstate("Telangana");
		obj.setMember();
		Thread.sleep(1000);
	}

	@When("^User enters all the valid data and clicks on the link next$")
	public void user_enters_all_the_valid_data_and_clicks_on_the_link_next() throws Throwable {
		obj.setFname("Supriya");
		obj.setLname("Palaparthi");
		obj.setEmail("supriya.palaparthi@capgemini.com");
		obj.setPhone("9966922993");
		obj.setPeople("3");
		obj.setAddress("110");
		obj.setAddress2("Chintal");
		obj.setScity("Hyderabad");
		obj.setSstate("Telangana");
		obj.setNonmember();
		obj.setClick();
		Thread.sleep(1000);
	}

	@Then("^Display alert message and navigate to payment details page$")
	public void display_alert_message_and_navigate_to_payment_details_page() throws Throwable {
		String alertMsg=driver.switchTo().alert().getText();
		System.out.println("***"+alertMsg);
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
	
		driver.navigate().to("file:///D:/BDD%20MPT%20case%20study/PaymentDetails.html/");
		Thread.sleep(2000);
		driver.close();
	}

}
