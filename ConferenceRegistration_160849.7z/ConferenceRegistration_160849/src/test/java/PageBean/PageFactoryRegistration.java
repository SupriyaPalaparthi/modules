package PageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class PageFactoryRegistration {
	
	WebDriver driver;
	
	@FindBy(name="txtFN")
	@CacheLookup
	WebElement fname;
	
	@FindBy(name="txtLN")
	@CacheLookup
	WebElement lname;
	
	@FindBy(name="Email")
	@CacheLookup
	WebElement email;
	
	@FindBy(name="Phone")
	@CacheLookup
	WebElement phone;
	
	@FindBy(how=How.NAME,using="size")
	@CacheLookup
	WebElement people;
	
	@FindBy(name="Address")
	@CacheLookup
	WebElement address;
	

	@FindBy(name="Address2")
	@CacheLookup
	WebElement address2;
	
	@FindBy(how=How.NAME,using="city")
	@CacheLookup
	WebElement scity;
	
	@FindBy(how=How.NAME,using="state")
	@CacheLookup
	WebElement sstate;
	
	@FindBy(xpath="html/body/form/table/tbody/tr[12]/td[2]/input")
	@CacheLookup
	WebElement member;
	
	@FindBy(xpath="html/body/form/table/tbody/tr[13]/td[2]/input")
	@CacheLookup
	WebElement nonmember;
	
	@FindBy(xpath="html/body/form/table/tbody/tr[14]/td/a")
	@CacheLookup
	WebElement click;
	
public PageFactoryRegistration(WebDriver driver) {
		
		this.driver = driver;
		PageFactory.initElements(driver, this);
		
	}

	public void setFname(String firstname) {
		fname.sendKeys(firstname);
	}

	public void setLname(String lastname) {
		lname.sendKeys(lastname);
	}

	public void setEmail(String semail) {
		email.sendKeys(semail);
	}

	public void setPhone(String mobile) {
		phone.sendKeys(mobile);
	}

	public void setPeople(String speople) {
		people.sendKeys(speople);
	}

	public void setAddress(String saddress) {
		address.sendKeys(saddress);
	}

	public void setAddress2(String saddress2) {
		address2.sendKeys(saddress2);;
	}

	public void setScity(String scity1) {
		scity.sendKeys(scity1);;
	}

	public void setSstate(String sstate1) {
		sstate.sendKeys(sstate1);;
	}

	public void setMember() {
		member.click();
	}

	public void setNonmember() {
		nonmember.click();
	}

	public void setClick() {
		click.click();
	}

	public WebDriver getDriver() {
		return driver;
	}

	public WebElement getFname() {
		return fname;
	}

	public WebElement getLname() {
		return lname;
	}

	public WebElement getEmail() {
		return email;
	}

	public WebElement getPhone() {
		return phone;
	}

	public WebElement getPeople() {
		return people;
	}

	public WebElement getAddress() {
		return address;
	}

	public WebElement getAddress2() {
		return address2;
	}

	public WebElement getScity() {
		return scity;
	}

	public WebElement getSstate() {
		return sstate;
	}

	public WebElement getMember() {
		return member;
	}

	public WebElement getNonmember() {
		return nonmember;
	}

	public WebElement getClick() {
		return click;
	}
	
}
