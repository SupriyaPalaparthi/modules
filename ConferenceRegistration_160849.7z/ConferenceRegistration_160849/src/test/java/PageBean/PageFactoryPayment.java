package PageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PageFactoryPayment {
	
WebDriver driver;
	
	@FindBy(name="txtFN")
	@CacheLookup
	WebElement cardholdername;
	
	@FindBy(name="debit")
	@CacheLookup
	WebElement cardnumber;

	@FindBy(name="cvv")
	@CacheLookup
	WebElement cvv;
	
	@FindBy(name="month")
	@CacheLookup
	WebElement month;
	
	@FindBy(name="year")
	@CacheLookup
	WebElement year;
	
	@FindBy(xpath=".//*[@id='btnPayment']")
	@CacheLookup
	WebElement button;

	public PageFactoryPayment(WebDriver driver2) {
		this.driver=driver2;
		PageFactory.initElements(driver, this);
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public void setCardholdername(String cardholdername1) {
		cardholdername.sendKeys(cardholdername1);
	}

	public void setCardnumber(String cardnumber1) {
		cardnumber.sendKeys(cardnumber1);
	}

	public void setCvv(String cvv1) {
		cvv.sendKeys(cvv1);
	}

	public void setMonth(String month1) {
		month.sendKeys(month1);;
	}

	public void setYear(String year1) {
		year.sendKeys(year1);;
	}

	public void setButton() {
		button.click();
	}

	public WebDriver getDriver() {
		return driver;
	}

	public WebElement getCardholdername() {
		return cardholdername;
	}

	public WebElement getCardnumber() {
		return cardnumber;
	}

	public WebElement getCvv() {
		return cvv;
	}

	public WebElement getMonth() {
		return month;
	}

	public WebElement getYear() {
		return year;
	}

	public WebElement getButton() {
		return button;
	}
	
}
