package PaymentDetails;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import PageBean.PageFactoryPayment;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefPayment {
	
	private WebDriver driver;
	private PageFactoryPayment objp;
	
	public void alertMsg() throws InterruptedException {
		String alertMsg=driver.switchTo().alert().getText();
		System.out.println("***"+alertMsg);
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
	}
	
	@Given("^User is on the payment details page$")
	public void user_is_on_the_payment_details_page() throws Throwable {
		driver=new FirefoxDriver();
	    objp=new PageFactoryPayment(driver);
	    Thread.sleep(1000);
	    driver.get("file:///D:/BDD%20MPT%20case%20study/PaymentDetails.html/");
	}

	@Then("^The title is verified$")
	public void the_title_is_verified() throws Throwable {
		if(driver.getTitle().contentEquals("Payment Details"))
			   System.out.println("***Title Matched***");
		   else
			   System.out.println("***Title mismatch***");
		   
		   driver.close();
	}

	@When("^User leaves card holder name blank and clicks on the link make payment$")
	public void user_leaves_card_holder_name_blank_and_clicks_on_the_link_make_payment() throws Throwable {
		objp.setCardholdername("");
	}

	@Then("^Display alert message$")
	public void display_alert_message() throws Throwable {
		objp.setButton();
	    alertMsg();
	    driver.close(); 
	}

	@When("^User leaves debit card number blank and clicks on the link make payment$")
	public void user_leaves_debit_card_number_blank_and_clicks_on_the_link_make_payment() throws Throwable {
		objp.setCardholdername("Priya");
	    objp.setCardnumber("");
	}

	@When("^User leaves card expiration month blank and clicks on the link make payment$")
	public void user_leaves_card_expiration_month_blank_and_clicks_on_the_link_make_payment() throws Throwable {
		objp.setCardholdername("Priya");
	    objp.setCardnumber("1236 5478");
	    objp.setCvv("123");
	    objp.setMonth("");
	    Thread.sleep(2000);
	}

	@When("^User leaves card expiration year blank and clicks on the link make payment$")
	public void user_leaves_card_expiration_year_blank_and_clicks_on_the_link_make_payment() throws Throwable {
		objp.setCardholdername("Priya");
	    objp.setCardnumber("1236 5478");
	    objp.setCvv("123");
	    objp.setMonth("Oct");
	    objp.setYear("");
	    Thread.sleep(2000);
	}

	@When("^User enters all valid data and clicks on the link make payment$")
	public void user_enters_all_valid_data_and_clicks_on_the_link_make_payment() throws Throwable {
		objp.setCardholdername("Priya");
	    objp.setCardnumber("1236 5478");
	    objp.setCvv("123");
	    objp.setMonth("Oct");
	    objp.setYear("2020");
	    Thread.sleep(2000);
	}

}
