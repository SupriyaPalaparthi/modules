package com.cg.ScheduledSessions.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ScheduledSessions1")
public class Schedule {
	@Id
	@Column(name="name")
	String sessionName;
	@Column(name="duration")
	Integer duration;
	@Column(name="faculty_name")
	String facultyName;
	@Column(name="mode1")
	String Mode;
	
	public Schedule(){
		
	}
	
	
	@Override
	public String toString() {
		return "Schedule [sessionName=" + sessionName + ", duration="
				+ duration + ", facultyName=" + facultyName + ", Mode=" + Mode
				+ "]";
	}
	
	public String getSessionName() {
		return sessionName;
	}
	public void setSessionName(String sessionName) {
		this.sessionName = sessionName;
	}
	public Integer getDuration() {
		return duration;
	}
	public void setDuration(Integer duration) {
		this.duration = duration;
	}
	public String getFacultyName() {
		return facultyName;
	}
	public void setFacultyName(String facultyName) {
		this.facultyName = facultyName;
	}
	public String getMode() {
		return Mode;
	}
	public void setMode(String mode) {
		Mode = mode;
	}
	
	
	public Schedule(String sessionName, Integer duration, String facultyName,
			String mode) {
		super();
		this.sessionName = sessionName;
		this.duration = duration;
		this.facultyName = facultyName;
		Mode = mode;
	}
	
}
