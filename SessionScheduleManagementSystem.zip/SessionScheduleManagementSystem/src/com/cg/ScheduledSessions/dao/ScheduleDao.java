package com.cg.ScheduledSessions.dao;

import java.util.List;

import com.cg.ScheduledSessions.dto.Schedule;

public interface ScheduleDao {
	
	public List<Schedule> getAllDetails();

}
