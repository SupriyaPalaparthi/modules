package com.cg.ScheduledSessions.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.ScheduledSessions.dto.Schedule;

@Repository("scheduledao")
public class ScheduleDaoImpl implements ScheduleDao {
@PersistenceContext
EntityManager em;

	@SuppressWarnings("unchecked")
	@Override
	public List<Schedule> getAllDetails() {
		// TODO Auto-generated method stub
		Query queryGet=em.createQuery("FROM Schedule");
		List<Schedule> myList=queryGet.getResultList();
		return myList;
		
	}

}
