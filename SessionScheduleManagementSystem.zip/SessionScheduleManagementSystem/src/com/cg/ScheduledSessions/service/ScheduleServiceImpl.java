package com.cg.ScheduledSessions.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ScheduledSessions.dao.ScheduleDao;
import com.cg.ScheduledSessions.dto.Schedule;

@Service("scheduleservice")
@Transactional
public class ScheduleServiceImpl implements ScheduleService{

	@Autowired
	ScheduleDao scheduledao;
	@Override
	public List<Schedule> getAllDetails() {
		// TODO Auto-generated method stub
		
		return scheduledao.getAllDetails();
	}

}
