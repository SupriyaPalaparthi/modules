package com.cg.ScheduledSessions.service;

import java.util.List;

import com.cg.ScheduledSessions.dto.Schedule;

public interface ScheduleService {
	
	public List<Schedule> getAllDetails();

}
