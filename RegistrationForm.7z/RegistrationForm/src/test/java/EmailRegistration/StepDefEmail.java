package EmailRegistration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import PageBean.PageFactoryEmail;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefEmail {
	
	private WebDriver driver;
	private PageFactoryEmail obj;
	
	@Given("^User is on email registration page$")
	public void user_is_on_email_registration_page() throws Throwable {
		 driver= new FirefoxDriver();
		   obj= new PageFactoryEmail(driver);
		   driver.get("file://///ndafile/Study%20Materials/VnV/Module%204/Lesson%205-HTML%20Pages/WorkingWithForms.html/");
	}

	@Then("^check the title of the page$")
	public void check_the_title_of_the_page() throws Throwable {
		 if(driver.getTitle().contentEquals("Email Registration Form"))
		    {
		    	System.out.println("******Title Matched");
		    }
		    else
		    	System.out.println("****Title Not Matched");
		    
		    driver.close(); 
	}

	@Then("^check the heading of the page$")
	public void check_the_heading_of_the_page() throws Throwable {
		String heading=driver.findElement(By.xpath("html/body/h1")).getText();
		  if(heading.contentEquals("Email Registration"))
		  {
			  System.out.println("****Heading Matched");
		  }
		  else
			  System.out.println("****Heading Not Matched");
		  driver.close();
	}

	@When("^user enters all the fields$")
	public void user_enters_all_the_fields() throws Throwable {
		obj.setUname("supriya");
	    obj.setPasswd("priya9966");
	    obj.setCnfrmpwd("priya9966");
	    obj.setFname("Supriya");
	    obj.setLname("Palaparthi");
	      Thread.sleep(3000);
	    obj.setFemale();
	    obj.setBirth("30th Oct 1996");
	    obj.setEmail("priya@gmail.com");
	    obj.setAddrs("hyd");
	    obj.setCity("Pune");
	                Thread.sleep(3000);
	    obj.setPhone("9966922993");
	    obj.setMusic();
	    obj.setReading();
	    Thread.sleep(3000);
	}

	@Then("^submit the form$")
	public void submit_the_form() throws Throwable {
		obj.setSubmt();
	    driver.close();
	}

	@When("^user enters wrong confirmation password and clicks the submit button$")
	public void user_enters_wrong_confirmation_password_and_clicks_the_submit_button() throws Throwable {
		obj.setPasswd("priya9966");
	    obj.setCnfrmpwd("priya12");
	                     Thread.sleep(3000);
	    obj.setSubmt();
	               Thread.sleep(3000);
	}

	@Then("^display alert message$")
	public void display_alert_message() throws Throwable {
		String str=driver.switchTo().alert().getText();
		   System.out.println(str);
			driver.switchTo().alert().accept();
	                 		Thread.sleep(3000);
			driver.close();
	}

	@When("^user enters incorrect email format and clicks the submit button$")
	public void user_enters_incorrect_email_format_and_clicks_the_submit_button() throws Throwable {
		obj.setEmail("priya");
        Thread.sleep(3000);
         obj.setSubmt();
        Thread.sleep(3000);
	}

	@Then("^email alert message$")
	public void email_alert_message() throws Throwable {
		System.out.println("Email Alert Message");
		   driver.close();
	}

	@When("^user clicks on reset button$")
	public void user_clicks_on_reset_button() throws Throwable {
		  obj.setReset();
	}

	@Then("^clear all details$")
	public void clear_all_details() throws Throwable {
		System.out.println("resetted");
		  driver.close();
	}



}
