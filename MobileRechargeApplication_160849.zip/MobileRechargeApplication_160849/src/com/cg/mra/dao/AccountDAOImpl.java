package com.cg.mra.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.mra.beans.AccountBeans;

public class AccountDAOImpl implements AccountDAO {
	
	Map<String,AccountBeans> accountEntry;

	public AccountDAOImpl() {
		accountEntry= new HashMap<>();
		accountEntry.put("9010210131", new AccountBeans("Prepaid", "Vaishali", 200));
		accountEntry.put("9823920123", new AccountBeans("Prepaid", "Megha", 453));
		accountEntry.put("9932012345", new AccountBeans("Prepaid", "Vikas", 631));
		accountEntry.put("9010210132", new AccountBeans("Prepaid", "Anju", 521));
	    accountEntry.put("9010210133", new AccountBeans("Prepaid", "Tushar", 632));
	
	}
	

	@Override
	public AccountBeans getAccountDetails(String mobileNo) {
	
		if(accountEntry.containsKey(mobileNo))
		return accountEntry.get(mobileNo);
		return null;
	}

	@Override
	public double rechargeAccount(String mobileNo, double rechargeAmount) {
		double b=0;
		if(accountEntry.containsKey(mobileNo))
		{
			AccountBeans ac = accountEntry.get(mobileNo);
			b=rechargeAmount+ac.getAccountBalance();
			
		}
		
				return b ;
	}

}
