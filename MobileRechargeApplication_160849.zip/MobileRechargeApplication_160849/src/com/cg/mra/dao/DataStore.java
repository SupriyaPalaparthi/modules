package com.cg.mra.dao;

import java.util.HashMap;

import com.cg.mra.beans.AccountBeans;


public class DataStore {
		
		private static HashMap<Integer, AccountBeans> account;
		
		public static HashMap<Integer, AccountBeans> createCollection(){
			
			if(account == null)
				account = new HashMap<>();
			
			return account;
			
	}
		}

