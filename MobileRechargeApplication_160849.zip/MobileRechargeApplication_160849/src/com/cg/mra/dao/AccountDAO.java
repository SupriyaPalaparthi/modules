package com.cg.mra.dao;

import com.cg.mra.beans.AccountBeans;


public interface AccountDAO {
	
	public AccountBeans getAccountDetails(String mobileNo);
	 public double rechargeAccount(String mobileNo, double rechargeAmount);
}
