package com.cg.mra.service;

import com.cg.mra.beans.AccountBeans;
import com.cg.mra.exception.AccountException;

public interface AccountService {
	

	AccountBeans getAccountDetails1(String mobileNo);
	//Account is taken as AccountBeans
	
	  double rechargeAccount(String mobileNo, double rechargeAmount);
	 
	 public void ValidateAccountBeans void getAccountDetails(String mobileNo);
		//Account is taken as AccountBeans
		

		public boolean validateMobileNo(String mobileNo) throws AccountException;

		public boolean validateamount(double reamt);
		 
		 
	 
	 

}
