package com.cg.mra.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.mra.beans.AccountBeans;
import com.cg.mra.dao.AccountDAO;
import com.cg.mra.dao.AccountDAOImpl;
import com.cg.mra.exception.AccountException;

public abstract class AccountServiceImpl implements AccountService {
	
	AccountDAO dao;
	

	public AccountServiceImpl() {
		dao = new AccountDAOImpl();
		
	}

	@Override
	//Account is taken as AccountBeans
	public AccountBeans getAccountDetails1(String mobileNo) {
		
	return dao.getAccountDetails(mobileNo);
		

	}

	@Override
	public double rechargeAccount(String mobileNo, double rechargeAmount) {
		
		return dao.rechargeAccount(mobileNo, rechargeAmount);
	}


	@Override
	public boolean validateMobileNo(String mobileNo) throws AccountException {
		// TODO Auto-generated method stub
		if(mobileNo==null)
			throw new AccountException("Null value found");
		Pattern p=Pattern.compile("[9][0-9]{9}");
		Matcher m=p.matcher(mobileNo);
		return m.matches();
	
	}


	@Override
	public boolean validateamount(double reamt) {
		// TODO Auto-generated method stub
		if(reamt>0)
			return true;
		return false;
	}


}
