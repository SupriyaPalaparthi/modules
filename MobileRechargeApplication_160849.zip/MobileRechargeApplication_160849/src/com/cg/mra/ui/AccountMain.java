package com.cg.mra.ui;

import java.util.Scanner;

import com.cg.mra.beans.AccountBeans;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;


public class AccountMain {

	public AccountMain() {
		
		AccountService service= new AccountServiceImpl();
		Scanner sc=new Scanner(System.in);
		int a=0;
		
		String mobileNo, MobileNo;
		double rechargeAmount, newbal;
		
		
		while(a != 3){
		
			System.out.println("1.Account Balance Enquiry");
			System.out.println("2.Recharge Amount");
			System.out.println("3.exit");
			
				a=sc.nextInt();
		switch(a){
		
	case 1:
		
	
		System.out.println("Enter mobile number");
		String mobileNo1 = sc.next();
		
		if(service.validateMobileNo(mobileNo))
		AccountBeans act = service.getAccountDetails(mobileNo);
		
		if(act==null){
			System.out.println("Given account Id Does Not Exists");
		else 
			System.out.println("Your Current Balance is Rs"+act.getAccountBalance());
		else  
			System.out.println("Enter 10 digit mobile number");	
		
	break;
		
	case 2:
		System.out.println("Enter mobile number");
		String mobileNo1 = sc.next();
		
		System.out.println("Enter recharge amount");
		double reamt = sc.nextDouble();
		
		
		
		if(service.validateMobileNo(mobileNo1))
		{
			if(reamt==0)
			{
				
			System.out.println("Recharge cannot be zero");
			}
			else if(service.validateamount(reamt))//creating method
			{
				double newbal1 = service.rechargeAmount(mobileNo1, reamt);
				
				if(newbal1==0)
				{
					System.out.println("Cannot Recharge Account as Given Mobile No Does Not Exists");
					
			}
			else
			{
				AccountBeans a1 = service.getAccountDetails(mobileNo1);
		System.out.println("Your Account is Recharged Successfully");
		
		System.out.println("Hello " +a1.getCustomerName()+", Available Balance is Rs"+newbal1);
			}
			}
			System.out.println("Enetr valid recharge amount");
		}
		}
		else
			
			System.out.println("Enter 10 digit number");
		break;
		
	}
		}


